import math
import random
import gym
from gym import spaces
import numpy as np

a = 1000
b = 10
r = 0.4
max = 999999

class Node:

    def __init__(self, x, y, p, s):
        self.x = x
        self.y = y
        self.p = p
        self.s = s


class Service:
    apply = False
    
    def __init__(self, apply):
        self.apply = apply

        
class Env(gym.Env):

    def __init__(self, nodeNum, serviceNum, xSize=100, ySize=100):
        self.nodeNum = nodeNum
        self.serviceNum = serviceNum
        self.action_space = spaces.Discrete(self.serviceNum+1)

        self.xSize = xSize
        self.ySize = ySize
        _shape = (nodeNum, 4)
        _low, _high, _obs_dtype = ((0, 255, np.float32))
        self.observation_space = spaces.Box(low=_low, high=_high, shape=_shape, dtype=_obs_dtype)
        self.flag = False
        # self.observation_space = spaces.Box(low=0, high=100, shape=(self.nodeNum,4), dtype=np.float32)
        
    def reset(self):
        if self.flag:
            for item in self.nodeList:
                item.s = 0
        else:
            self.nodeList = []
            for i in range(self.nodeNum):
                node = Node(self.xSize*random.random(), self.ySize*random.random(), 100*random.random(), 0)
                self.nodeList.append(node)
            self.nodeDistance()
        obs = []
        for item in self.nodeList:
            o = [item.x, item.y, item.p, item.s]
            obs.append(o)
        return np.array(obs, dtype=np.float32)
    
    def define(self, nodeList):
        if len(nodeList) == self.nodeNum:
            self.nodeList = nodeList
        self.distance()
            
    def nodeDistance(self):
        self.distance = []
        for i in range(self.nodeNum):
            distance = []
            node1 = self.nodeList[i]
            for j in range(self.nodeNum):
                node2 = self.nodeList[j]
                d = (node1.x-node2.x)*(node1.x-node2.x) + (node1.y-node2.y)*(node1.y-node2.y)
                d = math.sqrt(d)
                distance.append(d)
            self.distance.append(distance)
            
    def getReward(self):
        w = sum(i.p for i in self.nodeList if i.s != 0)
        u = sum(i.p for i in self.nodeList if i.s == 1)
        dmax = 0
        flag = 0
        for i in range(self.nodeNum):
            if self.nodeList[i].s ==1:
                flag = 1
                loc = i
                d = 0
                for j in range(self.serviceNum-1):
                    dmin = max
                    for k in range(self.nodeNum):
                        if self.nodeList[i].s == j+2:
                            if dmin < self.distance[loc][k]:
                                dmin = self.distance[loc][k]
                                loc = k
                    d += dmin
                dmax = d if d>dmax else dmax
        if flag == 0:
            dmax = max*max
        
        reward = a*u - b*w - r*dmax
        return reward
        
    def actionChose(self, i, service):
        if service > self.serviceNum:
            service = 0
        self.nodeList[i].s = service
        
    def step(self, i, action):
        self.actionChose(i, action)
        reward = self.getReward()
        obs = []
        for item in self.nodeList:
            o = [item.x, item.y, item.p, item.s]
            obs.append(o)
        return np.array(obs, dtype=np.float32), reward, i==self.nodeNum-1
    
    def render(self):
        print(self.getReward())
                    